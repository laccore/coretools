class SwingPadControllerTests extends GroovyTestCase {

    void testSomething() {

    }
}
