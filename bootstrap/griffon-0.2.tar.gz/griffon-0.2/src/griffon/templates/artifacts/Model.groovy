@artifact.package@import groovy.beans.Bindable

class @artifact.name@ {
   // @Bindable String propName
}