class ScriptControllerTests extends GroovyTestCase {

    void testSomething() {

    }
}
