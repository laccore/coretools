Contains code from http://code.google.com/p/gturtle/ used with explicit permission from Eitan Suez:

"I hereby grant the Griffon project and its developers free license to use any of the code in gturtle for
use in Griffon or Griffon samples or SwingPad for whatever purposes it would like, including the
right to redistribute parts of the code under the ASL2 license."
