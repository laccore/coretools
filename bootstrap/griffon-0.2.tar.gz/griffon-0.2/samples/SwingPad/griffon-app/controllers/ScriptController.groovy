class ScriptController {
    void mvcGroupInit(Map args) {
        app.controllers.root.populateFactorySet()
    }
}