import groovy.beans.Bindable

@Bindable class SmallForecastModel extends AbstractForecastModel {

    String day = '\u00a0\u00a0\u00a0'
}