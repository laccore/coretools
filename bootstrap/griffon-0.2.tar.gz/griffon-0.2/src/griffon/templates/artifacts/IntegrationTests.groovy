@artifact.package@import griffon.util.IGriffonApplication

class @artifact.name@ extends GroovyTestCase {

    IGriffonApplication app

    void testSomething() {

    }
}
