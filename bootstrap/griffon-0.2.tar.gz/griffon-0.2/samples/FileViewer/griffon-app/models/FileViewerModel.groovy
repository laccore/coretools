import groovy.beans.Bindable

class FileViewerModel {
   @Bindable String fileName = ""
}