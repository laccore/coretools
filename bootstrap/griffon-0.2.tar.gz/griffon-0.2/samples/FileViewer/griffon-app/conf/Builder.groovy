root {
    'groovy.swing.SwingBuilder' {
        controller = ['Threading']
        view = '*'
    }
    'griffon.app.ApplicationBuilder' {
        view = '*'
    }
}
/*
jx {
    'groovy.swing.SwingXBuilder' {
        view = '*'
    }
}
*/