class FilePanelControllerTests extends GroovyTestCase {

    void testSomething() {

    }
}
