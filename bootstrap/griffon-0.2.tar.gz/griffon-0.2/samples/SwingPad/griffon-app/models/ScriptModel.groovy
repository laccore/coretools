import groovy.beans.Bindable

class ScriptModel {
   // @Bindable String propName
}