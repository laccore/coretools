class FileViewerControllerTests extends GroovyTestCase {

    void testSomething() {

    }
}
