class GreetTests extends GroovyTestCase {

    void testSomething() {

    }
}
