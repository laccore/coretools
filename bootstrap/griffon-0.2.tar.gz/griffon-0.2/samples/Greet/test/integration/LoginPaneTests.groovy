class LoginPaneTests extends GroovyTestCase {

    void testSomething() {

    }
}
