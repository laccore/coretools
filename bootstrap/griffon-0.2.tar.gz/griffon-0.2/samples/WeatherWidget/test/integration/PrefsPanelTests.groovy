class PrefsPanelTests extends GroovyTestCase {

    void testSomething() {

    }
}
