class UserPaneTests extends GroovyTestCase {

    void testSomething() {

    }
}
