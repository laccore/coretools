class SmallForecastTests extends GroovyTestCase {

    void testSomething() {

    }
}
