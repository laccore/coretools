app.views.root.fontSize.setValue(24)
app.controllers.root.generateFonts()
app.views.root.textField.setText("The quick brown fox jumps over the lazy dog.")
